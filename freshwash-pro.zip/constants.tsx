
import React from 'react';
import { LaundryItem } from './types';

export const LAUNDRY_ITEMS: LaundryItem[] = [
  { id: '1', name: 'Shirt', price: 8, icon: '👕', category: 'Clothing' },
  { id: '2', name: 'Trousers', price: 10, icon: '👖', category: 'Clothing' },
  { id: '3', name: 'Dress', price: 15, icon: '👗', category: 'Clothing' },
  { id: '4', name: 'T-Shirt', price: 6, icon: '👕', category: 'Clothing' },
  { id: '5', name: 'Blanket', price: 25, icon: '🛌', category: 'Home' },
  { id: '6', name: 'Curtain', price: 30, icon: '🪟', category: 'Home' },
  { id: '7', name: 'Duvet', price: 40, icon: '🛌', category: 'Home' },
  { id: '8', name: 'Bedsheet', price: 15, icon: '🛏️', category: 'Home' },
  { id: '9', name: 'Socks', price: 3, icon: '🧦', category: 'Accessories' },
  { id: '10', name: 'Underwear', price: 4, icon: '🩲', category: 'Accessories' },
  { id: '11', name: 'Jacket', price: 20, icon: '🧥', category: 'Clothing' },
  { id: '12', name: 'Suit (2pc)', price: 35, icon: '🤵', category: 'Clothing' },
  { id: '13', name: 'Towel', price: 10, icon: '🛀', category: 'Home' },
  { id: '14', name: 'Jeans', price: 12, icon: '👖', category: 'Clothing' },
];

export const TIME_SLOTS = [
  '8:00 AM - 10:00 AM',
  '10:00 AM - 12:00 PM',
  '12:00 PM - 2:00 PM',
  '2:00 PM - 4:00 PM',
  '4:00 PM - 6:00 PM'
];

export const COLORS = {
  primary: '#06b6d4', // Cyan 500
  secondary: '#f97316', // Orange 500
  success: '#10b981', // Emerald 500
  danger: '#ef4444', // Red 500
  background: '#f8fafc',
};
