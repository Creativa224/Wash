
import React, { useState } from 'react';
import { UserRole } from '../types';

interface AuthViewProps {
  onLogin: (email: string, role: UserRole) => void;
  onSignup: (name: string, email: string, role: UserRole) => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLogin, onSignup }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [role, setRole] = useState<UserRole>(UserRole.CUSTOMER);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      onLogin(email, role);
    } else {
      onSignup(name, email, role);
    }
  };

  const roles = [
    { id: UserRole.CUSTOMER, label: 'Customer', icon: '🛍️' },
    { id: UserRole.RIDER, label: 'Rider', icon: '🛵' },
    { id: UserRole.WASHER, label: 'Washer', icon: '🫧' },
    { id: UserRole.ADMIN, label: 'Admin', icon: '⚡' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-500">
        {/* Header Toggle */}
        <div className="flex border-b border-slate-100">
          <button 
            onClick={() => setMode('login')}
            className={`flex-1 py-6 font-black text-sm uppercase tracking-widest transition-all ${mode === 'login' ? 'text-cyan-600 bg-cyan-50/50' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Login
          </button>
          <button 
            onClick={() => setMode('signup')}
            className={`flex-1 py-6 font-black text-sm uppercase tracking-widest transition-all ${mode === 'signup' ? 'text-cyan-600 bg-cyan-50/50' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Sign Up
          </button>
        </div>

        <div className="p-8 sm:p-10">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-cyan-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-cyan-100 mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
              {mode === 'login' ? 'Welcome Back!' : 'Join FreshWash Pro'}
            </h2>
            <p className="text-sm text-slate-500 font-medium mt-1">
              {mode === 'login' ? 'Enter your details to access your dashboard' : 'Start your premium laundry experience today'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 focus:ring-2 focus:ring-cyan-500 outline-none transition-all font-medium text-slate-800"
                />
              </div>
            )}
            
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 focus:ring-2 focus:ring-cyan-500 outline-none transition-all font-medium text-slate-800"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 focus:ring-2 focus:ring-cyan-500 outline-none transition-all font-medium text-slate-800"
              />
            </div>

            <div className="pt-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1 text-center">Select your role</label>
              <div className="grid grid-cols-2 gap-2">
                {roles.map(r => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setRole(r.id)}
                    className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all ${role === r.id ? 'bg-cyan-500 text-white border-cyan-500 shadow-lg shadow-cyan-100' : 'bg-white text-slate-600 border-slate-100 hover:border-slate-200'}`}
                  >
                    <span>{r.icon}</span>
                    <span>{r.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <button 
              type="submit"
              className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-base shadow-xl hover:bg-slate-800 transition-all active:scale-[0.98] mt-4"
            >
              {mode === 'login' ? 'Log In to Account' : 'Create My Account'}
            </button>
          </form>

          <div className="mt-8 text-center">
             <button className="text-[10px] font-bold text-slate-400 hover:text-cyan-600 transition-colors uppercase tracking-widest">
               Forgot your password?
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthView;
