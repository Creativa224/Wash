
export enum UserRole {
  GUEST = 'GUEST',
  CUSTOMER = 'CUSTOMER',
  RIDER = 'RIDER',
  WASHER = 'WASHER',
  ADMIN = 'ADMIN'
}

export enum OrderStatus {
  PENDING = 'Pending',
  AWAITING_PICKUP = 'Awaiting Pickup',
  EN_ROUTE_TO_WASHER = 'En Route to Washer',
  INCOMING = 'Incoming',
  WASHING = 'Washing',
  DRYING = 'Drying',
  IRONING = 'Ironing',
  READY = 'Ready',
  DELIVERING = 'Delivering',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

export enum PaymentMethod {
  CASH = 'CASH',
  MOBILE_MONEY = 'MOBILE_MONEY'
}

export interface LaundryItem {
  id: string;
  name: string;
  price: number;
  icon: string;
  category: 'Clothing' | 'Home' | 'Accessories';
}

export interface Order {
  id: string;
  customerId: string;
  items: Array<{ itemId: string; quantity: number }>;
  status: OrderStatus;
  total: number;
  address: string;
  timeSlot: string;
  riderId?: string;
  washerId?: string;
  createdAt: Date;
  paymentMethod?: PaymentMethod;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  avatar: string;
  githubUsername?: string;
  githubAvatar?: string;
  githubBio?: string;
  githubInsight?: string;
  verificationStatus?: 'Unverified' | 'Pending' | 'Verified';
  stats: {
    totalOrders: number;
    totalSpent: number;
    rating: number;
    activeOrders: number;
  };
}
