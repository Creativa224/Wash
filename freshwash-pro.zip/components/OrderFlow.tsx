
import React, { useState } from 'react';
import { LAUNDRY_ITEMS, TIME_SLOTS } from '../constants';
import { LaundryItem } from '../types';

interface Props {
  onCancel: () => void;
}

const OrderFlow: React.FC<Props> = ({ onCancel }) => {
  const [step, setStep] = useState(1);
  const [cart, setCart] = useState<{ [key: string]: number }>({});
  const [address, setAddress] = useState('');
  const [timeSlot, setTimeSlot] = useState(TIME_SLOTS[0]);
  const [isSuccess, setIsSuccess] = useState(false);

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => ({
      ...prev,
      [id]: Math.max(0, (prev[id] || 0) + delta)
    }));
  };

  // Add explicit types and casting for cart total calculation to avoid 'unknown' type errors
  const cartTotal = Object.entries(cart).reduce((acc: number, [id, qty]) => {
    const item = LAUNDRY_ITEMS.find(i => i.id === id);
    return acc + (item ? item.price * (qty as number) : 0);
  }, 0);

  // Cast Object.values to number[] to resolve '+' operator issues on unknown types
  const selectedItemsCount = (Object.values(cart) as number[]).reduce((a, b) => a + b, 0);

  const handleComplete = () => {
    setIsSuccess(true);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center animate-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-4xl mb-6 shadow-inner shadow-emerald-200/50">
          ✓
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Order Confirmed!</h2>
        <p className="text-slate-500 max-w-sm mb-8">
          Your pickup is scheduled for {timeSlot}. A rider will contact you when they are nearby.
        </p>
        <button 
          onClick={onCancel}
          className="bg-cyan-500 text-white px-8 py-3 rounded-xl font-bold hover:bg-cyan-600 transition-colors shadow-lg shadow-cyan-100"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  const renderStep1 = () => (
    <div className="space-y-6 animate-in slide-in-from-right duration-300">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900">Choose Items</h2>
        <span className="text-sm font-medium text-slate-500">{selectedItemsCount} items selected</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {LAUNDRY_ITEMS.map(item => (
          <div key={item.id} className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-2xl">{item.icon}</div>
              <div>
                <h4 className="font-bold text-slate-800">{item.name}</h4>
                <p className="text-sm text-cyan-600 font-medium">${item.price.toFixed(2)}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-slate-50 p-1.5 rounded-xl">
              <button 
                onClick={() => updateQuantity(item.id, -1)}
                className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 hover:text-slate-600 shadow-sm transition-colors"
              >
                -
              </button>
              <span className="w-6 text-center font-bold text-slate-800">{cart[item.id] || 0}</span>
              <button 
                onClick={() => updateQuantity(item.id, 1)}
                className="w-8 h-8 rounded-lg bg-cyan-500 text-white flex items-center justify-center shadow-sm hover:bg-cyan-600 transition-colors"
              >
                +
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-8 animate-in slide-in-from-right duration-300">
      <h2 className="text-2xl font-bold text-slate-900">Schedule Pickup</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Pickup Address</label>
          <div className="relative">
             <input 
              type="text" 
              placeholder="Enter your full address..." 
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-2xl px-5 py-4 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition-all shadow-sm"
            />
            <button className="absolute right-4 top-1/2 -translate-y-1/2 text-cyan-600 text-sm font-bold hover:text-cyan-700">
              Detect Location
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Time Slot</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {TIME_SLOTS.map(slot => (
              <button
                key={slot}
                onClick={() => setTimeSlot(slot)}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  timeSlot === slot 
                    ? 'border-cyan-500 bg-cyan-50 text-cyan-700 shadow-md ring-2 ring-cyan-500/10' 
                    : 'border-slate-100 bg-white text-slate-600 hover:border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold">{slot}</span>
                  {timeSlot === slot && (
                    <div className="w-5 h-5 bg-cyan-500 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-8 animate-in slide-in-from-right duration-300">
      <h2 className="text-2xl font-bold text-slate-900">Order Summary</h2>
      <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm overflow-hidden">
        <div className="space-y-4 mb-6">
          {Object.entries(cart).map(([id, qty]) => {
            // Cast qty to number for strict comparison and arithmetic
            const quantity = qty as number;
            if (quantity === 0) return null;
            const item = LAUNDRY_ITEMS.find(i => i.id === id);
            return (
              <div key={id} className="flex justify-between items-center pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{item?.icon}</span>
                  <div>
                    <p className="font-bold text-slate-800">{item?.name}</p>
                    <p className="text-sm text-slate-500">Qty: {quantity}</p>
                  </div>
                </div>
                {/* Cast quantity to number to fix arithmetic operation error */}
                <span className="font-bold text-slate-800">${((item?.price || 0) * quantity).toFixed(2)}</span>
              </div>
            );
          })}
        </div>
        
        <div className="bg-slate-50 -mx-6 -mb-6 p-6 space-y-3">
          <div className="flex justify-between text-slate-500">
            <span>Subtotal</span>
            <span>${cartTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-slate-500">
            <span>Delivery Fee</span>
            <span>$5.00</span>
          </div>
          <div className="flex justify-between text-xl font-bold text-slate-900 pt-2 border-t border-slate-200">
            <span>Total</span>
            <span className="text-cyan-600">${(cartTotal + 5).toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-2xl flex items-start gap-3">
        <div className="text-blue-500 mt-0.5">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
        </div>
        <div>
          <p className="text-sm font-bold text-blue-900">Pickup Location</p>
          <p className="text-sm text-blue-700">{address || 'No address specified'}</p>
          <p className="text-sm font-bold text-blue-900 mt-2">Pickup Time</p>
          <p className="text-sm text-blue-700">{timeSlot}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto py-4">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onCancel} className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors bg-white">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
        <div className="flex-1">
          <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-cyan-500 transition-all duration-500 ease-out"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>
        <span className="text-sm font-bold text-slate-400">Step {step}/3</span>
      </div>

      <div className="min-h-[400px]">
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
      </div>

      <div className="mt-12 flex gap-4">
        {step > 1 && (
          <button 
            onClick={() => setStep(step - 1)}
            className="flex-1 border border-slate-200 text-slate-600 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-colors"
          >
            Back
          </button>
        )}
        <button 
          onClick={() => step < 3 ? setStep(step + 1) : handleComplete()}
          disabled={step === 1 && selectedItemsCount === 0}
          className={`flex-[2] py-4 rounded-2xl font-bold shadow-lg transition-all ${
            step === 1 && selectedItemsCount === 0
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
              : 'bg-cyan-500 text-white hover:bg-cyan-600 shadow-cyan-100'
          }`}
        >
          {step === 3 ? 'Confirm Order' : 'Continue'}
        </button>
      </div>
    </div>
  );
};

export default OrderFlow;
