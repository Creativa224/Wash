
import React, { useEffect, useState } from 'react';
import WhatsAppButton from './WhatsAppButton';
import { soundManager } from '../utils/audio';

const AdminDashboard: React.FC = () => {
  const [alerts, setAlerts] = useState([
    { id: 1, color: 'rose' as const, title: 'Inventory Low', msg: 'Detergent supplies at Warehouse South are below 10% threshold.', time: '2m ago' },
    { id: 2, color: 'amber' as const, title: 'Delayed Pickup', msg: 'Rider #402 reported traffic delay for Order ORD-9921.', time: '15m ago' },
  ]);

  // Trigger admin sound when a new alert is detected
  useEffect(() => {
    if (alerts.length > 0) {
      soundManager.play('ADMIN');
    }
  }, [alerts]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">System Overview</h1>
          <p className="text-slate-500 text-sm">Real-time business performance analytics.</p>
        </div>
        <div className="flex gap-2">
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors">
            Download Report
          </button>
          <button className="bg-cyan-500 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-cyan-600 transition-colors shadow-lg shadow-cyan-100">
            System Config
          </button>
        </div>
      </section>

      {/* Main Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Revenue (MTD)" value="$12,840" delta="+14.2%" trend="up" />
        <MetricCard label="Active Orders" value="482" delta="+22" trend="up" />
        <MetricCard label="Avg Turnaround" value="18.5h" delta="-2h" trend="down" />
        <MetricCard label="Customer Rating" value="4.88" delta="+0.02" trend="up" />
      </div>

      {/* Charts / Large Data Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">Order Frequency</h3>
            <select className="bg-slate-50 border-none rounded-lg text-xs font-bold text-slate-500 p-1 px-2 outline-none">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-64 bg-slate-50 rounded-2xl border border-dashed border-slate-200 flex items-center justify-center text-slate-400 font-medium">
            <div className="text-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-2 opacity-20"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
              Interactive Visualization Placeholder
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-6">Top Performing Riders</h3>
          <div className="space-y-4">
            {[
              { name: 'Mike Ross', orders: 142, rating: 4.9, avatar: 'M', phone: '1234567890' },
              { name: 'Harvey Specter', orders: 128, rating: 5.0, avatar: 'H', phone: '0987654321' },
              { name: 'Donna Paulsen', orders: 115, rating: 4.8, avatar: 'D', phone: '5556667777' },
              { name: 'Rachel Zane', orders: 98, rating: 4.7, avatar: 'R', phone: '8889990000' },
            ].map(rider => (
              <div key={rider.name} className="flex items-center justify-between p-3 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-50 text-indigo-600 font-bold rounded-xl flex items-center justify-center">
                    {rider.avatar}
                  </div>
                  <div>
                    <p className="font-bold text-slate-800 text-sm">{rider.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">{rider.orders} Completed</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs font-bold text-slate-700">★ {rider.rating}</p>
                  </div>
                  <WhatsAppButton 
                    phone={rider.phone} 
                    message={`Hi ${rider.name}, I'm contacting you from the FreshWash Pro admin desk.`}
                    variant="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  />
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 text-cyan-600 text-xs font-bold uppercase tracking-wider border border-cyan-100 rounded-xl hover:bg-cyan-50 transition-colors">
            View All Staff
          </button>
        </div>
      </div>

      {/* Recent Alerts */}
      <section>
        <h3 className="font-bold text-slate-800 mb-4">System Alerts</h3>
        <div className="grid gap-3">
          {alerts.map(alert => (
            <Alert key={alert.id} color={alert.color} title={alert.title} msg={alert.msg} time={alert.time} />
          ))}
        </div>
      </section>
    </div>
  );
};

// Fixed: Using React.FC to handle reserved props like 'key' correctly
const MetricCard: React.FC<{ label: string, value: string, delta: string, trend: 'up' | 'down' }> = ({ label, value, delta, trend }) => (
  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group">
    <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-bl-[60px] -mr-8 -mt-8 transition-transform group-hover:scale-110"></div>
    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 relative z-10">{label}</p>
    <div className="flex items-end gap-2 relative z-10">
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      <p className={`text-xs font-bold mb-1 ${trend === 'up' ? 'text-emerald-500' : 'text-rose-500'}`}>
        {delta}
      </p>
    </div>
  </div>
);

// Fixed: Added interface for AlertProps and used React.FC to handle reserved props like 'key' correctly
interface AlertProps {
  color: 'rose' | 'amber';
  title: string;
  msg: string;
  time: string;
}

const Alert: React.FC<AlertProps> = ({ color, title, msg, time }) => (
  <div className={`flex items-start gap-4 p-4 rounded-2xl border ${
    color === 'rose' ? 'bg-rose-50/50 border-rose-100' : 'bg-amber-50/50 border-amber-100'
  }`}>
    <div className={`w-2 h-2 rounded-full mt-2 ${color === 'rose' ? 'bg-rose-500' : 'bg-amber-500'}`}></div>
    <div className="flex-1">
      <div className="flex items-center justify-between">
        <p className={`font-bold text-sm ${color === 'rose' ? 'text-rose-900' : 'text-amber-900'}`}>{title}</p>
        <p className="text-[10px] text-slate-400 font-bold uppercase">{time}</p>
      </div>
      <p className="text-xs text-slate-500 mt-0.5">{msg}</p>
    </div>
  </div>
);

export default AdminDashboard;
