
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';

interface HeaderProps {
  user: UserProfile;
  currentView: string;
  onNavigate: (view: 'dashboard' | 'new-order' | 'profile' | 'orders') => void;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, currentView, onNavigate, onLogout }) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="bg-white border-b border-slate-100 sticky top-0 z-40">
      <div className="container mx-auto max-w-5xl px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <div className="w-10 h-10 bg-cyan-500 rounded-xl flex items-center justify-center text-white shadow-md shadow-cyan-100">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
          </div>
          <span className="font-bold text-xl text-slate-800 tracking-tight hidden sm:inline">FreshWash<span className="text-cyan-500">Pro</span></span>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          <NavItem active={currentView === 'dashboard'} onClick={() => onNavigate('dashboard')} label="Home" />
          <NavItem active={currentView === 'orders'} onClick={() => onNavigate('orders')} label="My Orders" />
          <NavItem active={false} onClick={() => {}} label="Training" />
          <NavItem active={currentView === 'profile'} onClick={() => onNavigate('profile')} label="Profile" />
        </nav>

        <div className="flex items-center gap-3">
          {user.role === UserRole.CUSTOMER && (
            <button 
              onClick={() => onNavigate('new-order')}
              className="hidden md:flex bg-cyan-500 hover:bg-cyan-600 text-white px-5 py-2 rounded-lg font-medium transition-all"
            >
              Schedule Pickup
            </button>
          )}
          
          <div className="relative" ref={dropdownRef}>
            <button 
              onClick={() => setShowDropdown(!showDropdown)}
              className="w-10 h-10 rounded-full bg-slate-100 border-2 border-white shadow-sm overflow-hidden flex items-center justify-center transition-transform active:scale-95"
            >
              <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
            </button>

            {showDropdown && (
              <div className="absolute top-12 right-0 w-48 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 animate-in zoom-in-95 origin-top-right">
                <button 
                  onClick={() => { onNavigate('profile'); setShowDropdown(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <span className="text-lg">👤</span> Profile
                </button>
                <button 
                  onClick={() => { onLogout(); setShowDropdown(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-500 hover:bg-rose-50 transition-colors"
                >
                  <span className="text-lg">🚪</span> Log Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

const NavItem = ({ active, label, onClick }: { active: boolean, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
      active ? 'bg-cyan-50 text-cyan-600' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
    }`}
  >
    {label}
  </button>
);

export default Header;
