
import React, { useEffect } from 'react';
import { UserProfile, UserRole, OrderStatus, Order } from '../types';
import WhatsAppButton from './WhatsAppButton';
import { soundManager } from '../utils/audio';

interface Props {
  user: UserProfile;
  orders: Order[];
  onNewOrder: () => void;
  onViewAllOrders: () => void;
  onTrackOrder: (id: string) => void;
}

const CustomerDashboard: React.FC<Props> = ({ user, orders, onNewOrder, onViewAllOrders, onTrackOrder }) => {
  const isGuest = user.role === UserRole.GUEST;

  const activeOrders = orders.filter(o => 
    o.status !== OrderStatus.COMPLETED && o.status !== OrderStatus.CANCELLED
  );

  // Status mapping for progress bar
  const getProgress = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.PENDING: return 5;
      case OrderStatus.AWAITING_PICKUP: return 20;
      case OrderStatus.EN_ROUTE_TO_WASHER: return 40;
      case OrderStatus.WASHING: return 55;
      case OrderStatus.DRYING: return 70;
      case OrderStatus.IRONING: return 85;
      case OrderStatus.READY: return 95;
      case OrderStatus.DELIVERING: return 90;
      default: return 0;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Section */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
            Hello, <span className="text-cyan-500">{isGuest ? 'Friend' : user.name.split(' ')[0]}!</span>
          </h1>
          <p className="text-slate-500 mt-1">Fresh clothes, delivered to your door.</p>
        </div>
        <button className="relative w-10 h-10 bg-white border border-slate-200 rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-50 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">3</span>
        </button>
      </section>

      {/* Promo Banner */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-slate-900 p-8 text-white shadow-2xl">
        <div className="relative z-10 max-w-md">
          <span className="inline-block px-3 py-1 bg-cyan-500 text-white text-[10px] font-black rounded-full mb-4 uppercase tracking-widest">Premium Member</span>
          <h2 className="text-3xl font-black mb-2 leading-tight">Your clothes deserve a spa day.</h2>
          <p className="text-slate-400 mb-6 font-medium">Expert care for your favorite fabrics. Scheduled, picked up, and returned in 24 hours.</p>
          <button 
            onClick={onNewOrder}
            className="bg-cyan-500 text-white px-8 py-3 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-900/40"
          >
            Start New Order
          </button>
        </div>
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute top-10 right-10 opacity-30">
          <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="0.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></svg>
        </div>
      </div>

      {/* Active Tracking */}
      <section>
        <div className="flex items-center justify-between mb-6 px-2">
          <h3 className="text-xl font-black text-slate-800 tracking-tight">Active Tracking</h3>
          <button onClick={onViewAllOrders} className="text-cyan-600 text-sm font-black uppercase tracking-widest hover:text-cyan-700">History</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeOrders.length > 0 ? (
            activeOrders.map(order => (
              <div 
                key={order.id} 
                onClick={() => onTrackOrder(order.id)}
                className="bg-white border-2 border-slate-50 p-6 rounded-[2.5rem] shadow-sm hover:shadow-xl hover:border-cyan-100 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                      {order.status === OrderStatus.WASHING ? '🫧' : 
                       order.status === OrderStatus.AWAITING_PICKUP ? '🛵' : 
                       order.status === OrderStatus.DELIVERING ? '🚀' : '📦'}
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 text-lg">{order.id}</h4>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{order.status}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-slate-900">${order.total.toFixed(2)}</p>
                    <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Live Now</p>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                   <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                      <span>Order Placed</span>
                      <span>Delivery</span>
                   </div>
                   <div className="h-2.5 w-full bg-slate-50 rounded-full overflow-hidden p-0.5">
                      <div 
                        className="h-full bg-cyan-500 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${getProgress(order.status as OrderStatus)}%` }}
                      ></div>
                   </div>
                </div>

                <div className="flex items-center justify-between">
                   <div className="flex -space-x-2">
                      <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                        <img src="https://picsum.photos/seed/rider1/100" alt="Rider" />
                      </div>
                      <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                        <img src="https://picsum.photos/seed/washer1/100" alt="Washer" />
                      </div>
                   </div>
                   <div className="flex gap-2">
                      <WhatsAppButton phone="1234567890" variant="icon" className="!w-10 !h-10 !rounded-xl" />
                      <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center">→</div>
                   </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-16 text-center bg-white rounded-[2.5rem] border-2 border-dashed border-slate-100">
               <div className="text-4xl mb-4 grayscale opacity-20">🧊</div>
               <p className="font-black text-slate-900">No active laundry orders</p>
               <p className="text-slate-400 text-sm font-medium mt-1">When you place an order, track it here in real-time.</p>
               <button onClick={onNewOrder} className="mt-6 px-6 py-2.5 bg-slate-50 text-slate-900 font-black text-xs uppercase tracking-widest rounded-xl hover:bg-slate-100">Book Now</button>
            </div>
          )}
        </div>
      </section>

      {/* Services */}
      <section>
        <h3 className="text-xl font-black text-slate-800 mb-6 px-2">Premium Services</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <ServiceCard title="Wash & Fold" desc="Daily wear, expertly cleaned" icon="👕" price="from $1.50/lb" />
          <ServiceCard title="Dry Cleaning" desc="Silk, wool & delicate fabrics" icon="👔" price="from $8.00/pc" />
          <ServiceCard title="Eco Refresh" desc="Curtains, duvets & bedding" icon="🏠" price="from $15.00/pc" />
        </div>
      </section>
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: { label: string, value: string | number, icon: string, color: string }) => (
  <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
    <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center text-2xl mb-4`}>
      {icon}
    </div>
    <div className="text-2xl font-black text-slate-900">{value}</div>
    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{label}</div>
  </div>
);

const ServiceCard = ({ title, desc, icon, price }: { title: string, desc: string, icon: string, price: string }) => (
  <div className="bg-white p-8 rounded-[2.5rem] border-2 border-slate-50 shadow-sm hover:shadow-2xl hover:border-cyan-100 transition-all cursor-pointer group">
    <div className="text-5xl mb-6 group-hover:scale-110 transition-transform duration-500">{icon}</div>
    <h4 className="font-black text-slate-900 mb-2 text-lg">{title}</h4>
    <p className="text-sm text-slate-500 mb-6 leading-relaxed font-medium">{desc}</p>
    <div className="text-[10px] font-black text-cyan-600 uppercase tracking-widest py-1.5 px-3 bg-cyan-50 rounded-lg inline-block">{price}</div>
  </div>
);

export default CustomerDashboard;
