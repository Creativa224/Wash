
import React, { useState, useEffect, useRef } from 'react';
import { OrderStatus, PaymentMethod } from '../types';
import WhatsAppButton from './WhatsAppButton';
import { soundManager } from '../utils/audio';

interface IncomingOrder {
  id: string;
  address: string;
  items: number;
  estEarnings: number;
  totalToCollect: number;
  distance: string;
  pickupTime: string;
  customerPhone: string;
  lat: number;
  lng: number;
}

type RiderStage = 
  | 'IDLE' 
  | 'ACCEPTED' 
  | 'EN_ROUTE_TO_PICKUP' 
  | 'ARRIVED_AT_PICKUP' 
  | 'PICKED_UP' 
  | 'EN_ROUTE_TO_DELIVERY' 
  | 'ARRIVED_AT_DELIVERY'
  | 'COLLECTING_PAYMENT';

type SettingsView = 'NONE' | 'EARNINGS' | 'NAME' | 'PHOTO' | 'ID_VERIFY';

interface RiderDashboardProps {
  onLogout: () => void;
  onUpdateOrder: (id: string, status: OrderStatus) => void;
}

const MOCK_INCOMING: IncomingOrder = {
  id: 'ORD-7688',
  address: '15 Baker Street, NW1',
  items: 12,
  estEarnings: 18.50,
  totalToCollect: 45.00,
  distance: '0.8 km',
  pickupTime: '10:15 AM',
  customerPhone: '07700900123',
  lat: 30,
  lng: 40
};

const RiderDashboard: React.FC<RiderDashboardProps> = ({ onLogout, onUpdateOrder }) => {
  const [currentOrder, setCurrentOrder] = useState<any>(null);
  const [stage, setStage] = useState<RiderStage>('IDLE');
  const [progress, setProgress] = useState(0);
  const [incomingOffer, setIncomingOffer] = useState<IncomingOrder | null>(null);
  const [isAvailable, setIsAvailable] = useState(true);
  const [notification, setNotification] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [activeSettingsView, setActiveSettingsView] = useState<SettingsView>('NONE');
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  
  const [riderName, setRiderName] = useState('Mike Ross');
  const [isUpdating, setIsUpdating] = useState(false);
  
  const [realCoords, setRealCoords] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'searching' | 'locked' | 'error'>('searching');

  const settingsRef = useRef<HTMLDivElement>(null);
  const canSeeIncoming = isAvailable;

  useEffect(() => {
    if (incomingOffer && isAvailable && stage === 'IDLE') {
      soundManager.play('RIDER');
    }
  }, [incomingOffer, isAvailable, stage]);

  useEffect(() => {
    if (!navigator.geolocation) {
      setGpsStatus('error');
      return;
    }
    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        setRealCoords({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
        setGpsStatus('locked');
      },
      () => setGpsStatus('error'),
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 5000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  useEffect(() => {
    let interval: any;
    if ((stage === 'EN_ROUTE_TO_PICKUP' || stage === 'EN_ROUTE_TO_DELIVERY') && progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => {
          const next = prev + 10; // Faster simulation for testing
          return next >= 100 ? 100 : next;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [stage, progress]);

  useEffect(() => {
    if (isAvailable && stage === 'IDLE' && !incomingOffer) {
      const timer = setTimeout(() => setIncomingOffer(MOCK_INCOMING), 3000);
      return () => clearTimeout(timer);
    }
  }, [stage, isAvailable, incomingOffer]);

  const handleAccept = () => {
    if (stage === 'IDLE') {
      const order = { ...incomingOffer, status: OrderStatus.AWAITING_PICKUP };
      setCurrentOrder(order);
      setStage('ACCEPTED');
      setProgress(0);
      onUpdateOrder(order.id, OrderStatus.AWAITING_PICKUP);
    }
    setIncomingOffer(null);
  };

  const handleStartPickup = () => {
    setStage('EN_ROUTE_TO_PICKUP');
    onUpdateOrder(currentOrder.id, OrderStatus.AWAITING_PICKUP);
  };

  const handleConfirmPickup = () => {
    setStage('PICKED_UP');
    setProgress(0);
    onUpdateOrder(currentOrder.id, OrderStatus.EN_ROUTE_TO_WASHER);
  };

  const handleStartDelivery = () => {
    setStage('EN_ROUTE_TO_DELIVERY');
    onUpdateOrder(currentOrder.id, OrderStatus.DELIVERING);
  };

  const handleProcessPayment = (method: PaymentMethod) => {
    setPaymentProcessing(true);
    setTimeout(() => {
      setPaymentProcessing(false);
      setNotification(`Payment collected via ${method}. Order Completed.`);
      onUpdateOrder(currentOrder.id, OrderStatus.COMPLETED);
      setStage('IDLE');
      setCurrentOrder(null);
    }, 2000);
  };

  const closeSettings = () => setActiveSettingsView('NONE');

  const renderSettingsContent = () => {
    switch(activeSettingsView) {
      case 'EARNINGS':
        return (
          <div className="space-y-6">
            <div className="bg-slate-900 text-white p-6 rounded-[2rem]">
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Available Balance</p>
              <div className="text-3xl font-black">$452.80</div>
              <button className="mt-4 w-full py-3 bg-cyan-500 rounded-xl font-black text-sm uppercase">Withdraw Now</button>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black text-slate-400 uppercase ml-2">History</p>
              {['Oct 24 - $1,200', 'Oct 17 - $940', 'Oct 10 - $1,102'].map((h, i) => (
                <div key={i} className="p-4 bg-white border border-slate-100 rounded-2xl flex justify-between font-bold text-sm">
                  <span>{h.split(' - ')[0]}</span>
                  <span className="text-emerald-500">{h.split(' - ')[1]}</span>
                </div>
              ))}
            </div>
          </div>
        );
      case 'NAME':
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Update Name</label>
              <input type="text" value={riderName} onChange={(e) => setRiderName(e.target.value)} className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" />
            </div>
            <button onClick={() => { setIsUpdating(true); setTimeout(() => { setIsUpdating(false); closeSettings(); setNotification("Name updated."); }, 1000); }} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase text-xs tracking-widest">{isUpdating ? 'Updating...' : 'Save Name'}</button>
          </div>
        );
      case 'PHOTO':
        return (
          <div className="text-center space-y-6 py-4">
            <div className="w-32 h-32 rounded-[2.5rem] bg-slate-100 border-4 border-white shadow-xl mx-auto overflow-hidden">
               <img src="https://picsum.photos/seed/rider/200" className="w-full h-full object-cover" alt="Profile" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button className="py-4 bg-slate-50 rounded-2xl font-bold text-xs uppercase tracking-widest">Take Photo</button>
              <button className="py-4 bg-slate-50 rounded-2xl font-bold text-xs uppercase tracking-widest">Upload</button>
            </div>
          </div>
        );
      case 'ID_VERIFY':
        return (
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl text-[11px] font-bold text-amber-700">⚠️ Driver License expires in 12 days.</div>
            {['Front of ID', 'Back of ID', 'Insurance'].map((doc, i) => (
              <div key={i} className="p-4 bg-white border border-slate-100 rounded-2xl flex justify-between items-center group cursor-pointer hover:border-cyan-500">
                <span className="text-sm font-bold text-slate-700">{doc}</span>
                <span className="text-[10px] font-black text-cyan-500 uppercase">Replace</span>
              </div>
            ))}
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-10">
      {notification && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[60] bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-top-4">
          <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white">🔔</div>
          <p className="font-bold text-sm">{notification}</p>
        </div>
      )}

      {activeSettingsView !== 'NONE' && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={closeSettings}></div>
          <div className="relative w-full max-w-lg bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-2xl font-black text-slate-900">Settings</h3>
              <button onClick={closeSettings} className="w-10 h-10 bg-slate-50 text-slate-400 rounded-full">✕</button>
            </div>
            <div className="p-8 bg-slate-50/30">{renderSettingsContent()}</div>
          </div>
        </div>
      )}

      <section className="flex flex-col md:flex-row items-center justify-between bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm gap-4">
        <div className="flex items-center gap-5 w-full md:w-auto">
          <div className="relative cursor-pointer" onClick={() => setShowSettings(!showSettings)}>
            <div className="w-14 h-14 rounded-2xl bg-cyan-500 flex items-center justify-center text-white shadow-xl">
               <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></svg>
            </div>
            {showSettings && (
              <div ref={settingsRef} className="absolute top-16 left-0 w-64 bg-white rounded-[2rem] shadow-2xl border border-slate-100 p-4 z-[70] animate-in zoom-in-95 origin-top-left">
                <div className="space-y-1">
                  <DropdownItem icon="📄" label="Earnings" onClick={() => { setActiveSettingsView('EARNINGS'); setShowSettings(false); }} />
                  <DropdownItem icon="🖊️" label="Change Name" onClick={() => { setActiveSettingsView('NAME'); setShowSettings(false); }} />
                  <DropdownItem icon="📸" label="Upload Photo" onClick={() => { setActiveSettingsView('PHOTO'); setShowSettings(false); }} />
                  <DropdownItem icon="🆔" label="Verification" onClick={() => { setActiveSettingsView('ID_VERIFY'); setShowSettings(false); }} />
                </div>
                <button onClick={onLogout} className="w-full mt-4 py-3 bg-slate-50 text-slate-400 font-bold text-xs rounded-xl hover:bg-rose-50 hover:text-rose-500">Log Out</button>
              </div>
            )}
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 leading-tight">{riderName}</h1>
            <p className="text-sm text-slate-500 font-semibold">{isAvailable ? '🟢 Online' : '⚪ Offline'}</p>
          </div>
        </div>
        <button onClick={() => setIsAvailable(!isAvailable)} className={`px-6 py-3 rounded-2xl font-bold text-sm ${isAvailable ? 'bg-rose-50 text-rose-500' : 'bg-emerald-500 text-white'}`}>{isAvailable ? 'Go Offline' : 'Go Online'}</button>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 relative h-[500px] bg-slate-100 rounded-[3rem] overflow-hidden shadow-inner border-4 border-white">
          <div className="absolute top-6 left-6 z-40 space-y-2">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white/80 rounded-full shadow text-[10px] font-black uppercase">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              GPS: {gpsStatus}
            </div>
          </div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-14 h-14 bg-cyan-500 rounded-full flex items-center justify-center text-white shadow-2xl border-4 border-white animate-bounce-slow">
            📍
          </div>
        </div>

        <div className="space-y-6">
          {incomingOffer && canSeeIncoming && stage === 'IDLE' && (
            <div className="bg-slate-900 text-white rounded-[2.5rem] p-6 border-b-8 border-rose-500 shadow-2xl animate-in slide-in-from-right-10">
              <p className="text-[10px] font-black text-rose-400 uppercase mb-2">New Delivery Offer</p>
              <h3 className="text-xl font-black mb-4">{incomingOffer.address}</h3>
              <div className="flex gap-3">
                <button onClick={() => setIncomingOffer(null)} className="flex-1 py-4 rounded-2xl font-black bg-white/10 text-sm">Pass</button>
                <button onClick={handleAccept} className="flex-1 py-4 rounded-2xl font-black bg-cyan-500 text-sm">Accept</button>
              </div>
            </div>
          )}

          {stage !== 'IDLE' && currentOrder && (
            <div className="bg-white rounded-[2.5rem] p-6 border border-slate-100 shadow-xl space-y-4">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-2xl">👤</div>
                  <div><h4 className="font-black text-slate-900">Current Job</h4><p className="text-xs font-bold text-slate-500">{currentOrder.address}</p></div>
               </div>
               {stage === 'ACCEPTED' && <button onClick={handleStartPickup} className="w-full py-5 bg-cyan-500 text-white rounded-2xl font-black">🚀 Start Pickup</button>}
               {stage === 'EN_ROUTE_TO_PICKUP' && <button onClick={() => setStage('ARRIVED_AT_PICKUP')} disabled={progress < 100} className={`w-full py-5 rounded-2xl font-black ${progress < 100 ? 'bg-slate-100 text-slate-400' : 'bg-orange-500 text-white'}`}>📍 Arrived</button>}
               {stage === 'ARRIVED_AT_PICKUP' && <button onClick={handleConfirmPickup} className="w-full py-5 bg-emerald-500 text-white rounded-2xl font-black">✅ Confirm Pickup</button>}
               {stage === 'PICKED_UP' && <button onClick={handleStartDelivery} className="w-full py-5 bg-indigo-500 text-white rounded-2xl font-black">🚚 Start Delivery</button>}
               {stage === 'EN_ROUTE_TO_DELIVERY' && <button onClick={() => setStage('ARRIVED_AT_DELIVERY')} disabled={progress < 100} className={`w-full py-5 rounded-2xl font-black ${progress < 100 ? 'bg-slate-100 text-slate-400' : 'bg-emerald-500 text-white'}`}>🏁 Arrived</button>}
               {stage === 'ARRIVED_AT_DELIVERY' && <button onClick={() => setStage('COLLECTING_PAYMENT')} className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black">💰 Collect Payment</button>}
               {stage === 'COLLECTING_PAYMENT' && (
                 <div className="grid grid-cols-2 gap-3">
                   <button onClick={() => handleProcessPayment(PaymentMethod.MOBILE_MONEY)} className="py-4 bg-slate-100 rounded-xl font-bold text-xs">📱 Mobile</button>
                   <button onClick={() => handleProcessPayment(PaymentMethod.CASH)} className="py-4 bg-slate-100 rounded-xl font-bold text-xs">💵 Cash</button>
                 </div>
               )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const DropdownItem = ({ icon, label, onClick }: { icon: string, label: string, onClick?: () => void }) => (
  <button onClick={onClick} className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-50 text-left">
    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-xl">{icon}</div>
    <p className="text-sm font-bold text-slate-800">{label}</p>
  </button>
);

export default RiderDashboard;
