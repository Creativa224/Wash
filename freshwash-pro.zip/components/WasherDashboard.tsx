import React, { useState, useEffect } from 'react';
import { OrderStatus } from '../types';
import WhatsAppButton from './WhatsAppButton';
import { soundManager } from '../utils/audio';

interface WasherOrder {
  id: string;
  client: string;
  items: number;
  status: OrderStatus;
  priority: 'High' | 'Normal';
  timeIn: string;
  clientPhone: string;
  riderName?: string;
  riderProgress?: number;
  photoCaptured?: boolean;
}

const INITIAL_QUEUE: WasherOrder[] = [
  { id: 'ORD-7721', client: 'Alice Smith', items: 12, status: OrderStatus.WASHING, priority: 'High', timeIn: '20m ago', clientPhone: '1234567890' },
  { id: 'ORD-7688', client: 'John Doe', items: 5, status: OrderStatus.INCOMING, priority: 'Normal', timeIn: '5m ago', clientPhone: '0987654321' },
];

interface Props {
  onUpdateOrder: (id: string, status: OrderStatus) => void;
}

const WasherDashboard: React.FC<Props> = ({ onUpdateOrder }) => {
  const [filter, setFilter] = useState<OrderStatus | 'ALL'>(OrderStatus.INCOMING);
  const [washQueue, setWashQueue] = useState<WasherOrder[]>(INITIAL_QUEUE);
  const [activePhotoModal, setActivePhotoModal] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  useEffect(() => {
    const hasIncoming = washQueue.some(q => q.status === OrderStatus.INCOMING);
    if (hasIncoming) {
      soundManager.play('WASHER');
    }
  }, [washQueue]);

  useEffect(() => {
    const interval = setInterval(() => {
      setWashQueue(prev => prev.map(order => {
        if (order.status === OrderStatus.EN_ROUTE_TO_WASHER && (order.riderProgress || 0) < 100) {
          return { ...order, riderProgress: Math.min((order.riderProgress || 0) + 10, 100) };
        }
        return order;
      }));
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const handleAcceptOrder = (id: string) => {
    setWashQueue(prev => prev.map(order => 
      order.id === id ? { 
        ...order, 
        status: OrderStatus.EN_ROUTE_TO_WASHER, 
        riderName: 'Rider Mike', 
        riderProgress: 0,
        timeIn: 'Just now' 
      } : order
    ));
    setFilter(OrderStatus.EN_ROUTE_TO_WASHER);
    onUpdateOrder(id, OrderStatus.EN_ROUTE_TO_WASHER);
  };

  const handleOpenPhotoModal = (id: string) => {
    setActivePhotoModal(id);
    setCameraActive(true);
    setCapturedImage(null);
  };

  const takePhoto = () => {
    setCameraActive(false);
    setCapturedImage("https://images.unsplash.com/photo-1545173153-93d39502742f?q=80&w=600");
  };

  const handleConfirmPickup = () => {
    if (!activePhotoModal) return;
    setWashQueue(prev => prev.map(order => 
      order.id === activePhotoModal ? { ...order, status: OrderStatus.WASHING, photoCaptured: true } : order
    ));
    onUpdateOrder(activePhotoModal, OrderStatus.WASHING);
    setActivePhotoModal(null);
    setFilter(OrderStatus.WASHING);
  };

  const handleNextStep = (id: string, currentStatus: OrderStatus) => {
    const sequence = [OrderStatus.WASHING, OrderStatus.DRYING, OrderStatus.IRONING, OrderStatus.READY];
    const currentIndex = sequence.indexOf(currentStatus);
    if (currentIndex !== -1 && currentIndex < sequence.length - 1) {
      const nextStatus = sequence[currentIndex + 1];
      setWashQueue(prev => prev.map(order => 
        order.id === id ? { ...order, status: nextStatus } : order
      ));
      onUpdateOrder(id, nextStatus);
      setFilter(nextStatus);
    }
  };

  const handleDispatch = (id: string) => {
    setWashQueue(prev => prev.map(order => 
      order.id === id ? { ...order, status: OrderStatus.DELIVERING } : order
    ));
    onUpdateOrder(id, OrderStatus.DELIVERING);
    setFilter(OrderStatus.DELIVERING);
  };

  const statusColors: any = {
    [OrderStatus.INCOMING]: 'bg-slate-100 text-slate-600',
    [OrderStatus.EN_ROUTE_TO_WASHER]: 'bg-amber-100 text-amber-600',
    [OrderStatus.WASHING]: 'bg-blue-100 text-blue-600',
    [OrderStatus.DRYING]: 'bg-orange-100 text-orange-600',
    [OrderStatus.IRONING]: 'bg-indigo-100 text-indigo-600',
    [OrderStatus.READY]: 'bg-emerald-100 text-emerald-600',
    [OrderStatus.DELIVERING]: 'bg-cyan-100 text-cyan-600',
  };

  const filteredQueue = filter === 'ALL' ? washQueue : washQueue.filter(q => q.status === filter);

  const tabs = [
    { id: OrderStatus.INCOMING, label: 'Claims', icon: '📥' },
    { id: OrderStatus.EN_ROUTE_TO_WASHER, label: 'Inbound', icon: '🚚' },
    { id: OrderStatus.WASHING, label: 'Wash', icon: '🫧' },
    { id: OrderStatus.DRYING, label: 'Dry', icon: '💨' },
    { id: OrderStatus.IRONING, label: 'Iron', icon: '👔' },
    { id: OrderStatus.READY, label: 'Ready', icon: '✨' },
    { id: OrderStatus.DELIVERING, label: 'Outbound', icon: '🚀' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto pb-10">
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
        <div>
          <h1 className="text-2xl font-black text-slate-900 leading-tight">Washer Station Dashboard</h1>
          <p className="text-slate-500 text-sm font-medium">Location: <span className="text-cyan-600 font-black uppercase tracking-wider">Bay Area Hub - Station 7</span></p>
        </div>
        <div className="flex gap-4">
           <div className="bg-slate-50 px-5 py-3 rounded-2xl border border-slate-100 flex items-center gap-3">
             <div className="w-10 h-10 bg-emerald-50 text-emerald-500 rounded-xl flex items-center justify-center text-xl">✨</div>
             <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Efficiency</p>
                <p className="text-lg font-black text-slate-800">98.4%</p>
             </div>
           </div>
        </div>
      </section>

      <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={`px-5 py-3 rounded-2xl text-sm font-black whitespace-nowrap transition-all flex items-center gap-2 ${
              filter === tab.id 
                ? 'bg-slate-900 text-white shadow-xl shadow-slate-200 scale-105' 
                : 'bg-white text-slate-500 border border-slate-100 hover:border-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            {tab.label}
            <span className={`ml-1 px-2 py-0.5 rounded-lg text-[10px] ${filter === tab.id ? 'bg-white/20' : 'bg-slate-100'}`}>
              {washQueue.filter(q => q.status === tab.id).length}
            </span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredQueue.length > 0 ? (
          filteredQueue.map(item => (
            <div key={item.id} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 hover:shadow-md transition-all group border-l-8 border-l-slate-100" style={{ borderLeftColor: item.priority === 'High' ? '#ef4444' : '#f1f5f9' }}>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-5">
                  <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-3xl shadow-sm transition-transform ${statusColors[item.status as keyof typeof statusColors]}`}>
                    {item.status === OrderStatus.INCOMING ? '📥' :
                     item.status === OrderStatus.EN_ROUTE_TO_WASHER ? '🚚' :
                     item.status === OrderStatus.WASHING ? '🫧' : 
                     item.status === OrderStatus.DRYING ? '💨' :
                     item.status === OrderStatus.IRONING ? '👔' : 
                     item.status === OrderStatus.READY ? '✨' : '🚀'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-black text-slate-900 text-lg">{item.id}</h4>
                      {item.priority === 'High' && (
                        <span className="px-2 py-0.5 bg-rose-500 text-white text-[9px] font-black rounded-lg uppercase tracking-wider">Urgent</span>
                      )}
                    </div>
                    <p className="text-sm font-bold text-slate-500">{item.client} • {item.items} Items</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Received {item.timeIn}</p>
                  </div>
                </div>

                {item.status === OrderStatus.EN_ROUTE_TO_WASHER && (
                  <div className="flex-1 max-w-sm px-4">
                    <div className="flex justify-between mb-2">
                      <div className="flex items-center gap-2">
                         <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
                         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Rider: {item.riderName}</p>
                      </div>
                      <p className="text-[10px] font-black text-amber-600 tracking-widest">{item.riderProgress}% NEARBY</p>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 transition-all duration-1000" style={{ width: `${item.riderProgress}%` }}></div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  {item.status === OrderStatus.INCOMING ? (
                    <button 
                      onClick={() => handleAcceptOrder(item.id)}
                      className="bg-slate-900 text-white px-8 py-4 rounded-2xl text-sm font-black shadow-lg hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-2"
                    >
                      <span>🤝</span> Accept for Washing
                    </button>
                  ) : item.status === OrderStatus.EN_ROUTE_TO_WASHER ? (
                    <button 
                      onClick={() => handleOpenPhotoModal(item.id)}
                      disabled={(item.riderProgress || 0) < 100}
                      className={`px-8 py-4 rounded-2xl text-sm font-black transition-all flex items-center gap-2 shadow-lg ${
                        (item.riderProgress || 0) >= 100 
                          ? 'bg-amber-500 text-white shadow-amber-200 hover:bg-amber-600' 
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      { (item.riderProgress || 0) >= 100 ? 'Confirm Pickup & Photo' : 'Waiting for Rider...' }
                    </button>
                  ) : item.status === OrderStatus.READY ? (
                    <button 
                      onClick={() => handleDispatch(item.id)}
                      className="bg-emerald-500 text-white px-8 py-4 rounded-2xl text-sm font-black shadow-lg shadow-emerald-100 hover:bg-emerald-600 transition-all flex items-center gap-2"
                    >
                      🚀 Dispatch to Rider
                    </button>
                  ) : item.status !== OrderStatus.DELIVERING && (
                    <button 
                      onClick={() => handleNextStep(item.id, item.status as OrderStatus)}
                      className="bg-blue-600 text-white px-8 py-4 rounded-2xl text-sm font-black shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
                    >
                      Complete Current Step →
                    </button>
                  )}
                  
                  <WhatsAppButton phone={item.clientPhone} variant="icon" className="!bg-slate-50 !text-slate-400 !shadow-none border border-slate-100 hover:!bg-slate-100" />
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="py-32 text-center bg-white rounded-[3rem] border-4 border-dashed border-slate-100">
             <div className="text-7xl mb-6 grayscale opacity-20">🧊</div>
             <p className="text-xl font-black text-slate-900">This station is clear</p>
             <p className="text-slate-400 font-medium">No orders currently match your filter.</p>
          </div>
        )}
      </div>

      {activePhotoModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm" onClick={() => setActivePhotoModal(null)}></div>
          <div className="relative w-full max-w-xl bg-white rounded-[3.5rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)] animate-in zoom-in-95 duration-300">
            <div className="p-8 text-center bg-slate-50 border-b border-slate-100">
               <h3 className="text-3xl font-black text-slate-900">Logistics Check-In</h3>
               <p className="text-slate-500 font-bold mt-1 uppercase tracking-widest text-xs">Verify Receipt of {activePhotoModal}</p>
            </div>
            
            <div className="p-10">
              <div className="aspect-[4/3] bg-black rounded-[2.5rem] relative overflow-hidden flex items-center justify-center text-white ring-8 ring-slate-50 group">
                {capturedImage ? (
                  <div className="w-full h-full relative">
                    <img src={capturedImage} className="w-full h-full object-cover" alt="Captured laundry" />
                    <div className="absolute top-4 right-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase shadow-lg">Verified Snapshot</div>
                  </div>
                ) : cameraActive ? (
                  <div className="w-full h-full relative">
                    <div className="absolute inset-0 border-2 border-white/20 border-dashed m-10 rounded-2xl"></div>
                    <div className="absolute top-4 left-4 flex items-center gap-2">
                       <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                       <span className="text-[10px] font-black uppercase tracking-widest text-white">Live Stream</span>
                    </div>
                    <div className="w-full h-full flex flex-col items-center justify-center gap-4">
                       <div className="w-20 h-20 rounded-full border-4 border-white/30 animate-ping"></div>
                       <p className="font-bold text-white/50 animate-pulse">Position camera for quality check</p>
                    </div>
                    <button 
                      onClick={takePhoto}
                      className="absolute bottom-8 left-1/2 -translate-x-1/2 w-16 h-16 bg-white rounded-full border-4 border-slate-300 flex items-center justify-center shadow-2xl active:scale-90 transition-transform"
                    >
                      <div className="w-12 h-12 bg-slate-100 rounded-full border border-slate-200"></div>
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <p className="font-bold mb-4">Camera not enabled</p>
                    <button onClick={() => setCameraActive(true)} className="px-6 py-2 bg-white text-black rounded-xl font-bold">Enable Camera</button>
                  </div>
                )}
              </div>
            </div>

            <div className="p-8 bg-slate-50 flex gap-4">
              <button onClick={() => setActivePhotoModal(null)} className="flex-1 py-4 bg-white border border-slate-200 rounded-2xl font-black text-slate-500">Cancel</button>
              <button 
                disabled={!capturedImage}
                onClick={handleConfirmPickup}
                className={`flex-[2] py-4 rounded-2xl font-black text-white shadow-xl transition-all ${capturedImage ? 'bg-slate-900 hover:bg-slate-800' : 'bg-slate-200 cursor-not-allowed'}`}
              >
                Confirm Inventory & Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WasherDashboard;
