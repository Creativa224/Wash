
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Order, OrderStatus } from '../types';
import WhatsAppButton from './WhatsAppButton';

interface Props {
  order: Order;
  onBack: () => void;
}

const OrderTrackingDetail: React.FC<Props> = ({ order, onBack }) => {
  const [eta, setEta] = useState(12);
  const [progress, setProgress] = useState(0); 
  const [userLoc, setUserLoc] = useState<{ x: number, y: number } | null>(null);
  const requestRef = useRef<number>(null);
  const startTimeRef = useRef<number>(null);

  // Simulated coordinate path for the rider (normalized 0-100)
  const path = useMemo(() => [
    { x: 10, y: 15, name: 'Eco-Wash Hub' },
    { x: 25, y: 20, name: 'Industrial Way' },
    { x: 40, y: 45, name: 'Skyline Bridge' },
    { x: 60, y: 40, name: 'Downtown Avenue' },
    { x: 75, y: 65, name: 'Kensington Gardens' },
    { x: 88, y: 82, name: 'Arriving Soon' },
  ], []);

  // Get real user location and map it to our SVG space (simulated mapping)
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        // Just as a visual hint, we'll place the 'User' marker near the end of the path
        setUserLoc({ x: 88, y: 82 });
      });
    }
  }, []);

  // Animation Loop for smooth 60fps movement
  const animate = (time: number) => {
    if (startTimeRef.current === null) startTimeRef.current = time;
    const deltaTime = time - startTimeRef.current;
    
    // We want a full loop to take about 30 seconds
    const duration = 30000; 
    const p = (deltaTime % duration) / duration * 100;
    
    setProgress(p);
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    const isMoving = [
      OrderStatus.AWAITING_PICKUP, 
      OrderStatus.EN_ROUTE_TO_WASHER, 
      OrderStatus.DELIVERING
    ].includes(order.status as OrderStatus);

    if (isMoving) {
      requestRef.current = requestAnimationFrame(animate);
    } else {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      setProgress(0);
    }

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [order.status]);

  // Calculate current rider interpolated position
  const riderPos = useMemo(() => {
    const segments = path.length - 1;
    const rawIndex = (progress / 100) * segments;
    const index = Math.floor(rawIndex);
    const nextIndex = Math.min(index + 1, segments);
    const weight = rawIndex - index;

    const p1 = path[index];
    const p2 = path[nextIndex];

    return {
      x: p1.x + (p2.x - p1.x) * weight,
      y: p1.y + (p2.y - p1.y) * weight,
      road: p1.name
    };
  }, [progress, path]);

  const steps = [
    { status: OrderStatus.PENDING, label: 'Confirmed', icon: '📝' },
    { status: OrderStatus.AWAITING_PICKUP, label: 'Pickup', icon: '🛵' },
    { status: OrderStatus.WASHING, label: 'Processing', icon: '🫧' },
    { status: OrderStatus.DELIVERING, label: 'Delivery', icon: '🚀' },
    { status: OrderStatus.COMPLETED, label: 'Done', icon: '✨' },
  ];

  const currentStepIndex = steps.findIndex(s => {
    if ([OrderStatus.DRYING, OrderStatus.IRONING, OrderStatus.READY, OrderStatus.EN_ROUTE_TO_WASHER].includes(order.status)) {
      return s.status === OrderStatus.WASHING;
    }
    return s.status === order.status;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-24">
      {/* Header HUD */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="flex items-center gap-5">
          <button onClick={onBack} className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 hover:text-cyan-500 transition-all hover:scale-105">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m15 18-6-6 6-6"/></svg>
          </button>
          <div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">{order.id}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Live tracking active</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Current Destination</p>
            <p className="font-bold text-slate-700">{order.address}</p>
          </div>
          <div className="w-px h-10 bg-slate-100 mx-2 hidden sm:block"></div>
          <WhatsAppButton phone="1234567890" variant="icon" className="!w-14 !h-14 !rounded-2xl" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Vertical Progress */}
        <div className="lg:col-span-4 xl:col-span-3 space-y-6">
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm relative overflow-hidden">
            <div className="space-y-8 relative z-10">
              {steps.map((step, idx) => {
                const isPast = idx < currentStepIndex;
                const isCurrent = idx === currentStepIndex;
                return (
                  <div key={step.status} className="flex gap-5 relative">
                    {idx !== steps.length - 1 && (
                      <div className={`absolute left-[1.125rem] top-10 w-1 h-12 rounded-full transition-colors duration-500 ${isPast ? 'bg-cyan-500' : 'bg-slate-100'}`}></div>
                    )}
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg z-10 transition-all duration-500 border-2 ${
                      isPast ? 'bg-cyan-500 text-white border-cyan-500' : 
                      isCurrent ? 'bg-slate-900 text-white border-slate-900 shadow-xl scale-125' : 
                      'bg-white text-slate-300 border-slate-100'
                    }`}>
                      {isPast ? '✓' : step.icon}
                    </div>
                    <div className="flex-1 pt-0.5">
                      <p className={`font-black text-[11px] uppercase tracking-widest ${isCurrent ? 'text-slate-900' : isPast ? 'text-cyan-600' : 'text-slate-400'}`}>
                        {step.label}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
             <div className="relative z-10">
                <p className="text-[10px] font-black text-cyan-400 uppercase tracking-widest mb-2">Arrival Estimate</p>
                <h3 className="text-5xl font-black">{order.status === OrderStatus.COMPLETED ? '0' : eta} <span className="text-xl text-slate-500">min</span></h3>
                <div className="mt-6 flex items-center gap-3 bg-white/5 p-3 rounded-2xl border border-white/10">
                   <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center text-cyan-400">🔔</div>
                   <p className="text-[10px] font-bold text-slate-400">Get notified when rider is 2 mins away</p>
                </div>
             </div>
             <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl"></div>
          </div>
        </div>

        {/* Right Column: Dynamic Vector Map */}
        <div className="lg:col-span-8 xl:col-span-9 space-y-6">
           <div className="aspect-[16/9] bg-slate-950 rounded-[3.5rem] border-8 border-white shadow-2xl overflow-hidden relative group">
              {/* Animated Map Grid */}
              <div className="absolute inset-0 bg-[radial-gradient(#ffffff10_1.5px,transparent_1.5px)] [background-size:40px_40px] opacity-40"></div>
              
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                 {/* City Road Infrastructure (Vectorized) */}
                 <g className="opacity-10" stroke="white" strokeWidth="0.3" fill="none">
                    <path d="M0,20 L100,20 M0,40 L100,40 M0,60 L100,60 M0,80 L100,80" />
                    <path d="M20,0 L20,100 M40,0 L40,100 M60,0 L60,100 M80,0 L80,100" />
                 </g>

                 {/* Simulated Route Path Line */}
                 <polyline 
                   points={path.map(p => `${p.x},${p.y}`).join(' ')} 
                   stroke="white" 
                   strokeWidth="1.5" 
                   fill="none" 
                   strokeLinecap="round" 
                   strokeDasharray="4 6"
                   className="opacity-20"
                 />
                 
                 {/* Glowing Active Progress Path */}
                 <polyline 
                   points={path.map(p => `${p.x},${p.y}`).join(' ')} 
                   stroke="#06b6d4" 
                   strokeWidth="1.5" 
                   fill="none" 
                   strokeLinecap="round" 
                   className="animate-pulse shadow-glow"
                 />
              </svg>

              {/* Station Marker */}
              <div className="absolute" style={{ left: '10%', top: '15%', transform: 'translate(-50%, -50%)' }}>
                 <div className="w-14 h-14 bg-slate-900 rounded-[1.25rem] flex items-center justify-center text-2xl border-2 border-slate-800 shadow-2xl group-hover:scale-110 transition-transform cursor-help">
                    🏬
                    <div className="absolute -bottom-8 bg-black/80 backdrop-blur-md px-3 py-1 rounded-full text-[8px] font-black text-white uppercase tracking-widest whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">Main Washing Facility</div>
                 </div>
              </div>

              {/* User / Destination Marker */}
              <div className="absolute" style={{ left: '88%', top: '82%', transform: 'translate(-50%, -50%)' }}>
                 <div className="relative group/user">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-2xl border-4 border-cyan-500 shadow-[0_0_30px_rgba(6,182,212,0.4)] animate-pulse-slow">
                       🏠
                    </div>
                    <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-cyan-500 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest shadow-xl">You</div>
                    <div className="absolute inset-0 bg-cyan-400/20 rounded-full animate-ping pointer-events-none"></div>
                 </div>
              </div>

              {/* LIVE Rider Icon (The active part of tracking) */}
              <div 
                className="absolute z-30 transition-all duration-100 ease-linear" 
                style={{ left: `${riderPos.x}%`, top: `${riderPos.y}%`, transform: 'translate(-50%, -50%)' }}
              >
                <div className="relative">
                   <div className="w-12 h-12 bg-cyan-500 rounded-2xl flex items-center justify-center text-white border-4 border-white shadow-[0_0_20px_rgba(0,0,0,0.3)] animate-bounce-slow">
                      🛵
                   </div>
                   <div className="absolute -top-12 left-1/2 -translate-x-1/2 whitespace-nowrap">
                      <div className="bg-white/90 backdrop-blur-md px-4 py-1.5 rounded-full shadow-2xl border border-slate-100 flex items-center gap-2">
                         <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                         <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">{riderPos.road}</p>
                      </div>
                   </div>
                   {/* Direction Indicator */}
                   <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-cyan-500 rotate-45 border-r-2 border-b-2 border-white -z-10"></div>
                </div>
              </div>

              {/* Processing Visualizer (Hub Phase) */}
              {[OrderStatus.WASHING, OrderStatus.DRYING, OrderStatus.IRONING, OrderStatus.READY].includes(order.status as OrderStatus) && (
                <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px] z-40 flex items-center justify-center animate-in fade-in duration-500">
                   <div className="bg-white p-8 rounded-[3rem] shadow-2xl border border-slate-100 text-center max-w-xs scale-in-center">
                      <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center text-5xl mx-auto mb-6 relative">
                         🫧
                         <div className="absolute inset-0 border-4 border-cyan-500 rounded-[2rem] border-t-transparent animate-spin"></div>
                      </div>
                      <h4 className="text-xl font-black text-slate-900">Expert Cleaning</h4>
                      <p className="text-sm text-slate-500 mt-2 font-medium">Your items are being handled with premium care in Station 7.</p>
                   </div>
                </div>
              )}

              {/* Map Metadata HUD */}
              <div className="absolute bottom-8 left-8 right-8 flex items-center justify-between p-6 bg-slate-900/60 backdrop-blur-xl rounded-[2.5rem] border border-white/10 shadow-2xl pointer-events-none">
                 <div className="flex items-center gap-6">
                    <div className="flex flex-col">
                       <p className="text-[9px] font-black text-cyan-400 uppercase tracking-widest mb-1">Rider Speed</p>
                       <p className="text-xl font-black text-white tabular-nums">34 <span className="text-[10px] text-slate-400">km/h</span></p>
                    </div>
                    <div className="w-px h-8 bg-white/10"></div>
                    <div className="flex flex-col">
                       <p className="text-[9px] font-black text-cyan-400 uppercase tracking-widest mb-1">Distance</p>
                       <p className="text-xl font-black text-white tabular-nums">1.4 <span className="text-[10px] text-slate-400">km</span></p>
                    </div>
                 </div>
                 <div className="flex items-center gap-2 bg-emerald-500/20 px-4 py-2 rounded-full border border-emerald-500/30">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Signal Locked</p>
                 </div>
              </div>
           </div>

           {/* Professional Partners Card */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer hover:border-cyan-100 transition-all">
                 <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-slate-100 overflow-hidden ring-4 ring-slate-50 transition-transform group-hover:scale-105">
                       <img src="https://picsum.photos/seed/rider1/150" className="w-full h-full object-cover" alt="Rider" />
                    </div>
                    <div>
                       <h4 className="font-black text-slate-900 text-lg">Mike Ross</h4>
                       <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-amber-500 text-sm">★</span>
                          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">4.9 • 2,400+ Orders</p>
                       </div>
                    </div>
                 </div>
                 <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 group-hover:bg-cyan-50 group-hover:text-cyan-500 transition-all">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                 </div>
              </div>

              <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between">
                 <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center text-4xl shadow-inner">Hub</div>
                    <div>
                       <h4 className="font-black text-slate-900 text-lg">Eco-Wash Station</h4>
                       <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Certified • Solar Powered</p>
                    </div>
                 </div>
                 <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest">Verified</div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default OrderTrackingDetail;
