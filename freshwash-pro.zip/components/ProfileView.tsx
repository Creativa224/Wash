
import React, { useState } from 'react';
import { UserProfile, UserRole } from '../types';

interface Props {
  user: UserProfile;
  isAnalyzing: boolean;
  onRoleChange: (role: UserRole) => void;
  onConnectGithub: (username: string) => void;
  onDisconnectGithub: () => void;
  onGenerateInsight: () => void;
  onLogout: () => void;
}

const ProfileView: React.FC<Props> = ({ 
  user, 
  isAnalyzing,
  onRoleChange, 
  onConnectGithub, 
  onDisconnectGithub,
  onGenerateInsight,
  onLogout
}) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [ghInput, setGhInput] = useState('');

  const roles = [
    { id: UserRole.CUSTOMER, label: 'Customer', icon: '🛍️', desc: 'Book and track laundry' },
    { id: UserRole.RIDER, label: 'Rider', icon: '🛵', desc: 'Manage pickups and deliveries' },
    { id: UserRole.WASHER, label: 'Washer', icon: '🫧', desc: 'Manage laundry workflow' },
    { id: UserRole.ADMIN, label: 'Admin', icon: '⚡', desc: 'Complete system oversight' },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Profile Header */}
      <div className="bg-white rounded-3xl border border-slate-100 p-8 text-center shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-cyan-400 to-blue-500"></div>
        <div className="relative inline-block mb-4">
          <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-slate-100 mx-auto">
            <img src={user.githubAvatar || user.avatar} className="w-full h-full object-cover" alt={user.name} />
          </div>
          <button className="absolute bottom-0 right-0 w-8 h-8 bg-cyan-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white hover:bg-cyan-600 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
        </div>
        <h2 className="text-2xl font-bold text-slate-800">{user.name}</h2>
        <p className="text-slate-500">{user.email}</p>
        
        {user.role === UserRole.RIDER && (
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
              user.verificationStatus === 'Verified' ? 'bg-emerald-50 text-emerald-600' : 'bg-orange-50 text-orange-600'
            }`}>
              {user.verificationStatus || 'Unverified'} Status
            </span>
          </div>
        )}
      </div>

      {/* Account Actions */}
      <section className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
        <div className="flex flex-col gap-3">
           <button 
            onClick={onLogout}
            className="w-full py-4 bg-rose-50 text-rose-500 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-rose-100 transition-colors flex items-center justify-center gap-2"
           >
             <span>🚪</span> Log Out from Device
           </button>
        </div>
      </section>

      {/* Rider Documents (Specific to Rider Role) */}
      {user.role === UserRole.RIDER && (
        <section>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-1 h-6 bg-emerald-500 rounded-full"></div>
            <h3 className="text-lg font-bold text-slate-800">Verification Documents</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <DocumentUpload icon="🪪" label="Driving License" status="Uploaded" />
            <DocumentUpload icon="📄" label="National ID / Passport" status="Awaiting" />
            <DocumentUpload icon="🚲" label="Vehicle Registration" status="Uploaded" />
            <DocumentUpload icon="🏥" label="Medical Certificate" status="Awaiting" />
          </div>
        </section>
      )}

      {/* Integrations Section */}
      <section>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-1 h-6 bg-slate-800 rounded-full"></div>
          <h3 className="text-lg font-bold text-slate-800">Connected Accounts</h3>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center text-white">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
              </div>
              <div>
                <h4 className="font-bold text-slate-800">GitHub</h4>
                <p className="text-xs text-slate-500">{user.githubUsername ? `@${user.githubUsername}` : 'Sync profile data'}</p>
              </div>
            </div>
            {user.githubUsername ? (
              <button onClick={onDisconnectGithub} className="text-rose-500 text-xs font-bold uppercase">Disconnect</button>
            ) : (
              <button onClick={() => setGhInput('sarah-j')} className="text-cyan-600 text-xs font-bold uppercase">Connect</button>
            )}
          </div>
        </div>
      </section>

      {/* Role Switcher */}
      <section>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-1 h-6 bg-cyan-500 rounded-full"></div>
          <h3 className="text-lg font-bold text-slate-800">Change Perspective</h3>
        </div>
        <div className="grid gap-3">
          {roles.map(role => (
            <button
              key={role.id}
              onClick={() => onRoleChange(role.id)}
              className={`p-5 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                user.role === role.id ? 'border-cyan-500 bg-cyan-50 ring-2 ring-cyan-500/10' : 'border-slate-100 bg-white hover:border-slate-200'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-transform group-hover:scale-110 ${user.role === role.id ? 'bg-cyan-500 text-white' : 'bg-slate-50 text-slate-600'}`}>
                  {role.icon}
                </div>
                <div>
                  <h4 className={`font-bold ${user.role === role.id ? 'text-cyan-700' : 'text-slate-800'}`}>{role.label}</h4>
                  <p className="text-xs text-slate-500">{role.desc}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};

const DocumentUpload = ({ icon, label, status }: { icon: string, label: string, status: string }) => (
  <div className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between shadow-sm group cursor-pointer hover:border-cyan-200 transition-colors">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-xl">{icon}</div>
      <div className="text-left">
        <p className="text-sm font-bold text-slate-800 leading-tight">{label}</p>
        <p className={`text-[10px] font-black uppercase ${status === 'Uploaded' ? 'text-emerald-500' : 'text-slate-400'}`}>{status}</p>
      </div>
    </div>
    <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-cyan-50 group-hover:text-cyan-500 transition-colors">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    </div>
  </div>
);

export default ProfileView;
