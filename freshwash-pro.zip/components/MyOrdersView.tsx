
import React, { useState } from 'react';
import { OrderStatus } from '../types';

interface OrderItem {
  id: string;
  status: OrderStatus;
  itemsCount: number;
  date: string;
  total: number;
}

const INITIAL_ORDERS: OrderItem[] = [
  { id: 'ORD-7721', status: OrderStatus.WASHING, itemsCount: 12, date: 'Today, 2:30 PM', total: 42.50 },
  { id: 'ORD-7688', status: OrderStatus.AWAITING_PICKUP, itemsCount: 5, date: 'Tomorrow, 9:00 AM', total: 18.00 },
  { id: 'ORD-7600', status: OrderStatus.COMPLETED, itemsCount: 8, date: 'Mar 15, 2024', total: 35.20 },
  { id: 'ORD-7590', status: OrderStatus.COMPLETED, itemsCount: 3, date: 'Mar 12, 2024', total: 12.00 },
];

interface Props {
  onBack: () => void;
}

const MyOrdersView: React.FC<Props> = ({ onBack }) => {
  const [orders, setOrders] = useState<OrderItem[]>(INITIAL_ORDERS);
  const [orderToCancel, setOrderToCancel] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  const cancellableStatuses = [OrderStatus.PENDING, OrderStatus.AWAITING_PICKUP];

  const handleCancelClick = (id: string) => {
    setOrderToCancel(id);
  };

  const confirmCancel = () => {
    if (!orderToCancel) return;
    setIsCancelling(true);
    
    // Simulate API call
    setTimeout(() => {
      setOrders(prev => prev.map(order => 
        order.id === orderToCancel 
          ? { ...order, status: OrderStatus.CANCELLED } 
          : order
      ));
      setOrderToCancel(null);
      setIsCancelling(false);
    }, 800);
  };

  const closeDialog = () => {
    if (isCancelling) return;
    setOrderToCancel(null);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors bg-white">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
        <h2 className="text-2xl font-bold text-slate-900">My Orders</h2>
      </div>

      <div className="space-y-4">
        {orders.map(order => (
          <div key={order.id} className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${
                  order.status === OrderStatus.COMPLETED ? 'bg-emerald-50 text-emerald-500' :
                  order.status === OrderStatus.CANCELLED ? 'bg-slate-50 text-slate-400' :
                  'bg-cyan-50 text-cyan-500'
                }`}>
                  {order.status === OrderStatus.COMPLETED ? '✅' : 
                   order.status === OrderStatus.CANCELLED ? '✕' : '🕒'}
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">{order.id}</h4>
                  <p className="text-sm text-slate-500">{order.itemsCount} Items • {order.date}</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:items-end gap-2">
                <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  order.status === OrderStatus.COMPLETED ? 'bg-emerald-100 text-emerald-700' :
                  order.status === OrderStatus.CANCELLED ? 'bg-slate-100 text-slate-600' :
                  order.status === OrderStatus.WASHING ? 'bg-blue-100 text-blue-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {order.status}
                </span>
                <span className="font-bold text-slate-900">${order.total.toFixed(2)}</span>
              </div>
            </div>

            {cancellableStatuses.includes(order.status) && (
              <div className="mt-4 pt-4 border-t border-slate-50 flex justify-end">
                <button 
                  onClick={() => handleCancelClick(order.id)}
                  className="text-xs font-bold text-rose-500 hover:text-rose-600 uppercase tracking-wider flex items-center gap-1.5 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>
                  Cancel Order
                </button>
              </div>
            )}
          </div>
        ))}

        {orders.length === 0 && (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
            <p className="text-slate-400">You have no orders yet.</p>
          </div>
        )}
      </div>

      {/* Confirmation Dialog Modal */}
      {orderToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300"
            onClick={closeDialog}
          ></div>
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-sm p-8 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-3xl mb-6 mx-auto">
              ⚠️
            </div>
            <h3 className="text-xl font-bold text-slate-900 text-center mb-2">Cancel Order?</h3>
            <p className="text-slate-500 text-center text-sm mb-8 leading-relaxed">
              Are you sure you want to cancel order <span className="font-bold text-slate-800">{orderToCancel}</span>? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={closeDialog}
                disabled={isCancelling}
                className="flex-1 py-3 px-4 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
              >
                No, Keep it
              </button>
              <button 
                onClick={confirmCancel}
                disabled={isCancelling}
                className="flex-1 py-3 px-4 bg-rose-500 text-white rounded-xl font-bold hover:bg-rose-600 transition-all shadow-lg shadow-rose-100 flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isCancelling ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    Cancelling...
                  </>
                ) : 'Yes, Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyOrdersView;
