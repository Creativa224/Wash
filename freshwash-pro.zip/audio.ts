
/**
 * Utility to handle role-specific notification sounds.
 * Using standard UI sound assets from Google Actions library.
 */

export const SOUND_URLS = {
  RIDER: 'https://actions.google.com/sounds/v1/alarms/alarm_clock_short_beep.ogg',
  WASHER: 'https://actions.google.com/sounds/v1/cartoon/pop.ogg',
  CUSTOMER: 'https://actions.google.com/sounds/v1/messaging/messenger_send.ogg',
  ADMIN: 'https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg',
};

class SoundManager {
  private audios: Map<string, HTMLAudioElement> = new Map();

  constructor() {
    // Pre-load sounds
    Object.entries(SOUND_URLS).forEach(([key, url]) => {
      const audio = new Audio(url);
      audio.load();
      this.audios.set(key, audio);
    });
  }

  play(role: keyof typeof SOUND_URLS) {
    const audio = this.audios.get(role);
    if (audio) {
      audio.currentTime = 0;
      audio.play().catch(e => console.warn('Audio playback blocked by browser policy until user interacts.', e));
    }
  }
}

export const soundManager = new SoundManager();
