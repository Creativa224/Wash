
import React, { useState, useMemo, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { UserRole, UserProfile, Order, OrderStatus } from './types';
import Header from './components/Header';
import CustomerDashboard from './components/CustomerDashboard';
import RiderDashboard from './components/RiderDashboard';
import WasherDashboard from './components/WasherDashboard';
import AdminDashboard from './components/AdminDashboard';
import OrderFlow from './components/OrderFlow';
import ProfileView from './components/ProfileView';
import MyOrdersView from './components/MyOrdersView';
import AuthView from './components/AuthView';
import OrderTrackingDetail from './components/OrderTrackingDetail';
import { soundManager } from './utils/audio';

const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-7721',
    customerId: 'u1',
    items: [{ itemId: '1', quantity: 5 }, { itemId: '2', quantity: 2 }],
    status: OrderStatus.WASHING,
    total: 42.50,
    address: '72 Kensington Gardens, W8',
    timeSlot: '10:00 AM - 12:00 PM',
    createdAt: new Date(),
  },
  {
    id: 'ORD-7688',
    customerId: 'u1',
    items: [{ itemId: '4', quantity: 10 }],
    status: OrderStatus.AWAITING_PICKUP,
    total: 65.00,
    address: '15 Baker Street, NW1',
    timeSlot: '2:00 PM - 4:00 PM',
    createdAt: new Date(),
  }
];

const MOCK_USER_TEMPLATE: UserProfile = {
  id: 'u1',
  name: 'Sarah Johnson',
  email: 'sarah.johnson@email.com',
  phone: '1234567890',
  role: UserRole.CUSTOMER,
  avatar: 'https://picsum.photos/seed/sarah/200',
  stats: {
    totalOrders: 24,
    totalSpent: 1240,
    rating: 4.9,
    activeOrders: 2
  }
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'new-order' | 'profile' | 'orders' | 'tracking'>('dashboard');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [githubData, setGithubData] = useState<{ username: string; avatar: string; bio: string; insight?: string } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const currentUser = useMemo(() => {
    if (!user) return null;
    return {
      ...user,
      githubUsername: githubData?.username,
      githubAvatar: githubData?.avatar,
      githubBio: githubData?.bio,
      githubInsight: githubData?.insight
    };
  }, [user, githubData]);

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
    // Trigger customer sound for status updates
    if (user?.role === UserRole.CUSTOMER) {
      soundManager.play('CUSTOMER');
    }
  };

  const handleLogin = (email: string, role: UserRole) => {
    setUser({ 
      ...MOCK_USER_TEMPLATE, 
      email, 
      role, 
      name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1) 
    });
    setIsAuthenticated(true);
    setCurrentView('dashboard');
  };

  const handleSignup = (name: string, email: string, role: UserRole) => {
    setUser({ ...MOCK_USER_TEMPLATE, name, email, role });
    setIsAuthenticated(true);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setGithubData(null);
    setCurrentView('dashboard');
  };

  const handleRoleChange = (newRole: UserRole) => {
    if (user) {
      setUser({ ...user, role: newRole });
      setCurrentView('dashboard');
    }
  };

  const handleConnectGithub = async (username: string) => {
    try {
      const response = await fetch(`https://api.github.com/users/${username}`);
      if (!response.ok) throw new Error('User not found');
      const data = await response.json();
      setGithubData({
        username: data.login,
        avatar: data.avatar_url,
        bio: data.bio || 'This user prefers to keep their bio clean and minimal.'
      });
    } catch (err) {
      console.error('Github connection failed', err);
    }
  };

  const generateAIInsight = async () => {
    if (!githubData || isAnalyzing) return;
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Analyze this GitHub user's bio and data to create a fun "Laundry Personality" for a premium laundry app. 
      Username: ${githubData.username}
      Bio: ${githubData.bio}
      Be creative, witty, and relate their coding/tech life to laundry habits. 
      Keep it under 60 words. Start with a catchy title.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      const text = response.text;
      setGithubData(prev => prev ? { ...prev, insight: text } : null);
    } catch (err) {
      console.error('AI Insight failed', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDisconnectGithub = () => {
    setGithubData(null);
  };

  const handleTrackOrder = (id: string) => {
    setSelectedOrderId(id);
    setCurrentView('tracking');
  };

  const handleCreateOrder = (newOrderData: Partial<Order>) => {
    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: user?.id || 'u1',
      items: newOrderData.items || [],
      status: OrderStatus.PENDING,
      total: newOrderData.total || 0,
      address: newOrderData.address || '',
      timeSlot: newOrderData.timeSlot || '',
      createdAt: new Date(),
    };
    setOrders([newOrder, ...orders]);
    setCurrentView('dashboard');
    soundManager.play('CUSTOMER');
  };

  if (!isAuthenticated || !currentUser) {
    return <AuthView onLogin={handleLogin} onSignup={handleSignup} />;
  }

  const renderContent = () => {
    if (currentView === 'new-order') {
      return <OrderFlow onCancel={() => setCurrentView('dashboard')} onComplete={handleCreateOrder} />;
    }

    if (currentView === 'profile') {
      return (
        <ProfileView 
          user={currentUser} 
          isAnalyzing={isAnalyzing}
          onRoleChange={handleRoleChange} 
          onConnectGithub={handleConnectGithub}
          onDisconnectGithub={handleDisconnectGithub}
          onGenerateInsight={generateAIInsight}
          onLogout={handleLogout}
        />
      );
    }

    if (currentView === 'orders') {
      return <MyOrdersView onBack={() => setCurrentView('dashboard')} orders={orders} />;
    }

    if (currentView === 'tracking' && selectedOrderId) {
      const order = orders.find(o => o.id === selectedOrderId);
      return order ? (
        <OrderTrackingDetail order={order} onBack={() => setCurrentView('dashboard')} />
      ) : (
        <div className="text-center py-20">Order not found</div>
      );
    }

    switch (currentUser.role) {
      case UserRole.RIDER:
        return <RiderDashboard onLogout={handleLogout} onUpdateOrder={updateOrderStatus} />;
      case UserRole.WASHER:
        return <WasherDashboard onUpdateOrder={updateOrderStatus} />;
      case UserRole.ADMIN:
        return <AdminDashboard />;
      case UserRole.CUSTOMER:
      default:
        return (
          <CustomerDashboard 
            user={currentUser} 
            orders={orders}
            onNewOrder={() => setCurrentView('new-order')}
            onViewAllOrders={() => setCurrentView('orders')}
            onTrackOrder={handleTrackOrder}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header 
        user={currentUser} 
        onNavigate={setCurrentView} 
        currentView={currentView}
        onLogout={handleLogout}
      />
      
      <main className="flex-1 container mx-auto max-w-5xl px-4 py-6 pb-24 md:pb-12">
        {renderContent()}
      </main>

      {currentView === 'dashboard' && currentUser.role === UserRole.CUSTOMER && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 md:hidden z-50">
          <button 
            onClick={() => setCurrentView('new-order')}
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-3 rounded-full shadow-lg shadow-cyan-200 font-semibold flex items-center gap-2 transition-transform active:scale-95"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Schedule Pickup
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
